<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $product = $_POST['product'];
    $quantity = $_POST['quantity'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $email = $_POST['phone'];
    $address = $_POST['address'];

    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "creative section"; // Corrected database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL query to insert data into the database
    $sql = "INSERT INTO orders (product, quantity, name, email,phone, address) 
            VALUES ('$product', '$quantity', '$name', '$email','phone', '$address')";

    if ($conn->query($sql) === TRUE) {
        // Redirect to order confirmation page
        header("Location: orderconfirmation.html");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close connection
    $conn->close();
} else {
    // If the form is not submitted, redirect to the checkout page
    header("Location: checkout.php");
    exit;
}
?>
