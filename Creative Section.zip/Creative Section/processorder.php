<?php
// Connect to database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "creative section";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$product_id = $_POST['product'];
$quantity = $_POST['quantity'];
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];

// Retrieve product price from database
$sql = "SELECT price FROM products WHERE id = $product_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $price = $row['price'];

    // Calculate total price
    $total_price = $price * $quantity;

    // Insert order into database
    $sql = "INSERT INTO orders (product_id, quantity, name, email, phone, address, total_price)
            VALUES ($product_id, $quantity, '$name', '$email', '$phone', '$address', $total_price)";

    if ($conn->query($sql) === TRUE) {
        // Redirect to order confirmation page
        header("Location: orderconfirmation.html");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Product not found.";
}

$conn->close();
?>
